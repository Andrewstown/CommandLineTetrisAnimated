﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.Globalization;

namespace ConsoleTetris
{
    public class TetrisTable
    {
        private const string LeftMargin = "";
        private const string TopLeftJoint = "┌";
        private const string TopRightJoint = "┐";
        private const string BottomLeftJoint = "└";
        private const string BottomRightJoint = "┘";
        private const string HorizontalLine = "─";
        private const string VerticalLine = "│";

        private const string weight1 = "░";
        private const string weight2 = "▒";
        private const string weight3 = "▓";
        private const string weight4 = "█";

        private readonly int width = 1;
        private readonly int height = 1;
        
        public int Padding { get; set; } = 1;
 
        public TetrisTable(int width, int height)
        {
            this.width = width;
            this.height = height;
        }

        private StringBuilder CreateTopLine(StringBuilder formattedTable)
        {
            formattedTable.Append(LeftMargin);
            formattedTable.Append(TopLeftJoint);
            for (int i = 0; i < width; i++)
            {
                formattedTable.Append(HorizontalLine);
            }
            formattedTable.AppendLine(TopRightJoint);

            return formattedTable;
        }

        private StringBuilder CreateBottomLine(StringBuilder formattedTable)
        {
            formattedTable.Append(LeftMargin);
            formattedTable.Append(BottomLeftJoint);
            for (int i = 0; i < width; i++)
            {
                formattedTable.Append(HorizontalLine);
            }
            formattedTable.AppendLine(BottomRightJoint);

            return formattedTable;
        }

        private StringBuilder CreateMiddleLine(StringBuilder formattedTable)
        {
            formattedTable.Append(LeftMargin);
            formattedTable.Append(VerticalLine);
            for (int i = 0; i < width; i++)
            {
                formattedTable.Append(" ");
            }
            formattedTable.AppendLine(VerticalLine);

            return formattedTable;
        }

        public override string ToString()
        {
            var table = new List<string[]>();
            var formattedTable = new StringBuilder();

            formattedTable = CreateTopLine(formattedTable);
            for (int i = 0; i < height; i++)
            {
                formattedTable = CreateMiddleLine(formattedTable);
            }
            formattedTable = CreateBottomLine(formattedTable);

            return formattedTable.ToString();
        }
    }

}
