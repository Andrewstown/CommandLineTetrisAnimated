using System;
using System.Runtime.InteropServices;
using System.Text;

using static System.Console;

namespace ConsoleTetris
{
    class Program
    {
        const int HEIGHT = 20;
        const int WIDTH = 10;
        const string BLOCK = "▉";

        static int origRow;
        static int origCol;

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern Int32 SetCurrentConsoleFontEx(IntPtr ConsoleOutput, bool MaximumWindow, ref CONSOLE_FONT_INFO_EX ConsoleCurrentFontEx);

        private enum StdHandle
        {
            OutputHandle = -11
        }

        [DllImport("kernel32")]
        private static extern IntPtr GetStdHandle(StdHandle index);
        private static readonly IntPtr INVALID_HANDLE_VALUE = new IntPtr(-1);

        static void Main(string[] args)
        {
            CursorVisible = false;
            OutputEncoding = Encoding.Unicode;

            CONSOLE_FONT_INFO_EX ConsoleFontInfo = new CONSOLE_FONT_INFO_EX();
            ConsoleFontInfo.cbSize = (uint)Marshal.SizeOf(ConsoleFontInfo);

            ConsoleFontInfo.FaceName = "Cascadia Code";
            ConsoleFontInfo.dwFontSize.X = 36;
            ConsoleFontInfo.dwFontSize.Y = 36;

            SetCurrentConsoleFontEx(GetStdHandle(StdHandle.OutputHandle), false, ref ConsoleFontInfo);

            Clear();
            origRow = CursorTop;
            origCol = CursorLeft;

            ForegroundColor = ConsoleColor.DarkRed;
            TetrisTable t = new TetrisTable(10, 20);
            WriteLine(t.ToString());

            BackgroundColor = ConsoleColor.Black;

            string horizontalIBlock = BLOCK+BLOCK+BLOCK+BLOCK;

            ForegroundColor = ConsoleColor.Cyan;
            WriteAt(horizontalIBlock, 1, 1);
            ForegroundColor = ConsoleColor.Yellow;
            WriteAt(horizontalIBlock, 1, 2);
            ForegroundColor = ConsoleColor.Magenta;
            WriteAt(horizontalIBlock, 1, 3);
            ForegroundColor = ConsoleColor.Green;
            WriteAt(horizontalIBlock, 1, 4);
            ForegroundColor = ConsoleColor.Red;
            WriteAt(horizontalIBlock, 1, 5);
            ForegroundColor = ConsoleColor.DarkBlue;
            WriteAt(horizontalIBlock, 1, 6);
            ForegroundColor = ConsoleColor.DarkYellow;
            WriteAt(horizontalIBlock, 1, 7);

            ForegroundColor = ConsoleColor.White;
            CursorVisible = true;

        }

        protected static void WriteAt(string s, int x, int y)
        {
            try
            {
                SetCursorPosition(origCol+x, origRow+y);
                Write(s);
            }
            catch (ArgumentOutOfRangeException e)
            {
                Clear();
                WriteLine(e.Message);
            }
        }

        protected static void WriteAt(char c, int x, int y)
        {
            try
            {
                SetCursorPosition(origCol+x, origRow+y);
                Write(c);
            }
            catch (ArgumentOutOfRangeException e)
            {
                Clear();
                WriteLine(e.Message);
            }
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct CONSOLE_FONT_INFO_EX
        {
            public uint cbSize;
            public uint nFont;
            public COORD dwFontSize;
            public int FontFamily;
            public int FontWeight;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] // Edit sizeconst if the font name is too big
            public string FaceName;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct COORD
        {
            public short X;
            public short Y;

            public COORD(short X, short Y)
            {
            this.X = X;
            this.Y = Y;
            }
        };

        struct Point
        {
            public int x, y;

            public Point(int x, int y)
            {
                this.x = x;
                this.y = y;
            }
        }

    }
}
